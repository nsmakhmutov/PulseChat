// src/capture/wgc.rs — Windows Graphics Capture через windows crate
//
// Использует Direct3D 11 + Windows.Graphics.Capture для захвата монитора.
// Каждый вызов `grab()` возвращает CapturedFrame с BGRA данными.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;

use anyhow::{anyhow, Context, Result};
use parking_lot::Mutex;
use tracing::{debug, error, info, warn};

use windows::core::Interface;
use windows::Graphics::Capture::{
    Direct3D11CaptureFramePool, GraphicsCaptureItem, GraphicsCaptureSession,
};
use windows::Graphics::DirectX::DirectXPixelFormat;
use windows::Graphics::DirectX::Direct3D11::IDirect3DDevice;
use windows::Win32::Graphics::Direct3D::D3D_DRIVER_TYPE_HARDWARE;
use windows::Win32::Graphics::Direct3D11::{
    D3D11CreateDevice, ID3D11Device, ID3D11DeviceContext, ID3D11Texture2D,
    D3D11_CPU_ACCESS_READ, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
    D3D11_MAP_READ, D3D11_TEXTURE2D_DESC, D3D11_USAGE_STAGING,
    D3D11_SDK_VERSION, D3D11_BIND_FLAG, D3D11_RESOURCE_MISC_FLAG,
};
use windows::Win32::Graphics::Dxgi::Common::DXGI_FORMAT_B8G8R8A8_UNORM;
use windows::Win32::Graphics::Gdi::{
    EnumDisplayMonitors, GetMonitorInfoW, HMONITOR, MONITORINFOEXW,
};
use windows::Win32::System::WinRT::{
    CreateDirect3D11DeviceFromDXGIDevice,
    Graphics::Capture::IGraphicsCaptureItemInterop,
};

use super::CapturedFrame;

// ─── Перечисление мониторов ──────────────────────────────────────────────────

/// Информация о мониторе
#[derive(Debug, Clone)]
pub struct MonitorInfo {
    pub index: u32,
    pub handle: isize, // HMONITOR as isize
    pub name: String,
    pub width: u32,
    pub height: u32,
    pub x: i32,
    pub y: i32,
}

/// Перечисляет все подключённые мониторы через Win32 GDI.
pub fn enumerate_monitors() -> Vec<MonitorInfo> {
    let monitors: Arc<Mutex<Vec<MonitorInfo>>> = Arc::new(Mutex::new(Vec::new()));
    let monitors_clone = monitors.clone();

    unsafe {
        let _ = EnumDisplayMonitors(
            None,
            None,
            Some(monitor_enum_callback),
            windows::Win32::Foundation::LPARAM(
                &*monitors_clone as *const Mutex<Vec<MonitorInfo>> as isize,
            ),
        );
    }

    let result = monitors.lock().clone();
    info!("Обнаружено мониторов: {}", result.len());
    for m in &result {
        info!(
            "  Монитор {}: {} ({}×{}) @ ({}, {})",
            m.index, m.name, m.width, m.height, m.x, m.y
        );
    }
    result
}

unsafe extern "system" fn monitor_enum_callback(
    hmonitor: HMONITOR,
    _hdc: windows::Win32::Graphics::Gdi::HDC,
    _lprect: *mut windows::Win32::Foundation::RECT,
    lparam: windows::Win32::Foundation::LPARAM,
) -> windows::Win32::Foundation::BOOL {
    let monitors = &*(lparam.0 as *const Mutex<Vec<MonitorInfo>>);
    let mut info = MONITORINFOEXW::default();
    info.monitorInfo.cbSize = std::mem::size_of::<MONITORINFOEXW>() as u32;

    if GetMonitorInfoW(hmonitor, &mut info as *mut _ as *mut _).as_bool() {
        let rect = info.monitorInfo.rcMonitor;
        let name = String::from_utf16_lossy(
            &info.szDevice[..info.szDevice.iter().position(|&c| c == 0).unwrap_or(0)],
        );
        let mut lock = monitors.lock();
        let index = lock.len() as u32;
        lock.push(MonitorInfo {
            index,
            handle: hmonitor.0 as isize,
            name,
            width: (rect.right - rect.left) as u32,
            height: (rect.bottom - rect.top) as u32,
            x: rect.left,
            y: rect.top,
        });
    }
    windows::Win32::Foundation::BOOL(1) // TRUE — продолжить перечисление
}

// ─── D3D11 → WinRT interop ──────────────────────────────────────────────────

/// Создаёт D3D11 device + context (hardware accelerated)
fn create_d3d11_device() -> Result<(ID3D11Device, ID3D11DeviceContext)> {
    let mut device = None;
    let mut context = None;

    unsafe {
        D3D11CreateDevice(
            None,
            D3D_DRIVER_TYPE_HARDWARE,
            None,
            D3D11_CREATE_DEVICE_BGRA_SUPPORT,
            None, // feature levels — авто
            D3D11_SDK_VERSION,
            Some(&mut device),
            None,
            Some(&mut context),
        )
        .context("D3D11CreateDevice failed")?;
    }

    Ok((
        device.ok_or_else(|| anyhow!("D3D11 device is None"))?,
        context.ok_or_else(|| anyhow!("D3D11 context is None"))?,
    ))
}

/// Оборачивает D3D11Device в WinRT IDirect3DDevice для WGC
fn create_winrt_device(d3d_device: &ID3D11Device) -> Result<IDirect3DDevice> {
    unsafe {
        let dxgi_device: windows::Win32::Graphics::Dxgi::IDXGIDevice =
            d3d_device.cast().context("Cast to IDXGIDevice")?;

        let inspectable = CreateDirect3D11DeviceFromDXGIDevice(&dxgi_device)
            .context("CreateDirect3D11DeviceFromDXGIDevice")?;

        inspectable
            .cast::<IDirect3DDevice>()
            .context("Cast to IDirect3DDevice")
    }
}

/// Создаёт GraphicsCaptureItem для монитора по HMONITOR
fn capture_item_for_monitor(hmonitor: HMONITOR) -> Result<GraphicsCaptureItem> {
    unsafe {
        let interop: IGraphicsCaptureItemInterop =
            windows::core::factory::<GraphicsCaptureItem, IGraphicsCaptureItemInterop>()
                .context("IGraphicsCaptureItemInterop factory")?;

        interop
            .CreateForMonitor(hmonitor)
            .context("CreateForMonitor")
    }
}

// ─── ScreenCapture ───────────────────────────────────────────────────────────

/// Захват экрана через Windows Graphics Capture API.
///
/// Жизненный цикл:
///   1. `ScreenCapture::new(monitor_idx)` — инициализация D3D11 + WGC
///   2. `capture.grab()` — захват одного кадра (синхронный, блокирующий)
///   3. `drop` — автоматическая очистка ресурсов
pub struct ScreenCapture {
    d3d_device: ID3D11Device,
    d3d_context: ID3D11DeviceContext,
    _winrt_device: IDirect3DDevice,
    frame_pool: Direct3D11CaptureFramePool,
    session: GraphicsCaptureSession,
    staging_texture: Option<ID3D11Texture2D>,
    width: u32,
    height: u32,
    start_time: Instant,
    running: Arc<AtomicBool>,
}

impl ScreenCapture {
    /// Создаёт и запускает захват указанного монитора.
    ///
    /// `monitor_idx` — индекс из `enumerate_monitors()` (0 = основной).
    pub fn new(monitor_idx: u32) -> Result<Self> {
        info!("Инициализация WGC для монитора {monitor_idx}");

        // 1. D3D11 device
        let (d3d_device, d3d_context) = create_d3d11_device()?;
        info!("D3D11 device создан");

        // 2. WinRT device wrapper
        let winrt_device = create_winrt_device(&d3d_device)?;

        // 3. Находим монитор
        let monitors = enumerate_monitors();
        let monitor = monitors
            .iter()
            .find(|m| m.index == monitor_idx)
            .ok_or_else(|| anyhow!("Монитор {monitor_idx} не найден"))?;

        let hmonitor = HMONITOR(monitor.handle as *mut _);
        let width = monitor.width;
        let height = monitor.height;

        // 4. GraphicsCaptureItem
        let item = capture_item_for_monitor(hmonitor)?;
        info!("GraphicsCaptureItem создан для {}", monitor.name);

        // 5. Frame pool (1 буфер — мы обрабатываем синхронно)
        let frame_pool = Direct3D11CaptureFramePool::CreateFreeThreaded(
            &winrt_device,
            DirectXPixelFormat::B8G8R8A8UIntNormalized,
            1, // buffer count
            item.Size()?,
        )?;

        // 6. Session
        let session = frame_pool.CreateCaptureSession(&item)?;

        // Отключаем жёлтую рамку захвата (Win11 22H2+)
        #[allow(unused)]
        {
            // session.SetIsBorderRequired(false) — доступно начиная с Windows 11 22H2
            // Если метод не найден — рамка останется, но захват работает.
            let _ = session.SetIsBorderRequired(false);
        }

        session.StartCapture()?;
        info!("WGC сессия запущена: {width}×{height}");

        Ok(Self {
            d3d_device,
            d3d_context,
            _winrt_device: winrt_device,
            frame_pool,
            session,
            staging_texture: None,
            width,
            height,
            start_time: Instant::now(),
            running: Arc::new(AtomicBool::new(true)),
        })
    }

    /// Синхронный захват одного кадра.
    ///
    /// Возвращает `None` если кадр не готов (WGC ещё не отдал frame).
    /// Вызывай в цикле с нужной частотой (fps limiter снаружи).
    pub fn grab(&mut self) -> Result<Option<CapturedFrame>> {
        if !self.running.load(Ordering::Relaxed) {
            return Ok(None);
        }

        // TryGetNextFrame — неблокирующий
        let frame = match self.frame_pool.TryGetNextFrame() {
            Ok(f) => f,
            Err(_) => return Ok(None),
        };

        let surface = frame.Surface()?;
        let timestamp_ns = self.start_time.elapsed().as_nanos() as u64;

        // Получаем D3D11 texture из WinRT surface через interop
        let source_texture = self.surface_to_texture(&surface)?;

        // Размеры кадра (могут измениться при смене разрешения монитора)
        let mut desc = D3D11_TEXTURE2D_DESC::default();
        unsafe { source_texture.GetDesc(&mut desc) };
        let w = desc.Width;
        let h = desc.Height;

        // Создаём/пересоздаём staging texture если нужно
        self.ensure_staging_texture(w, h)?;
        let staging = self.staging_texture.as_ref().unwrap();

        unsafe {
            // GPU→GPU копия (очень быстро, ~0.1 мс)
            self.d3d_context.CopyResource(staging, &source_texture);

            // Map staging → CPU (одна копия GPU→RAM)
            let mapped = self.d3d_context.Map(staging, 0, D3D11_MAP_READ, 0)?;

            let src_stride = mapped.RowPitch;
            let dst_stride = w * 4;
            let mut data = vec![0u8; (h * dst_stride) as usize];

            // Копируем построчно (stride может быть > width*4)
            let src_ptr = mapped.pData as *const u8;
            for row in 0..h {
                let src_offset = (row * src_stride) as isize;
                let dst_offset = (row * dst_stride) as usize;
                std::ptr::copy_nonoverlapping(
                    src_ptr.offset(src_offset),
                    data[dst_offset..].as_mut_ptr(),
                    dst_stride as usize,
                );
            }

            self.d3d_context.Unmap(staging, 0);

            // Закрываем frame — возвращаем буфер в пул
            frame.Close()?;

            Ok(Some(CapturedFrame {
                data,
                width: w,
                height: h,
                stride: dst_stride,
                timestamp_ns,
            }))
        }
    }

    /// Конвертирует WinRT IDirect3DSurface → ID3D11Texture2D
    fn surface_to_texture(
        &self,
        surface: &windows::Graphics::DirectX::Direct3D11::IDirect3DSurface,
    ) -> Result<ID3D11Texture2D> {
        unsafe {
            // WinRT surface → IDirect3DDxgiInterfaceAccess → ID3D11Texture2D
            let access: windows::Win32::System::WinRT::Direct3D11::IDirect3DDxgiInterfaceAccess =
                surface.cast().context("Cast surface to DxgiInterfaceAccess")?;
            access
                .GetInterface::<ID3D11Texture2D>()
                .context("GetInterface<ID3D11Texture2D>")
        }
    }

    /// Создаёт staging texture для Map (CPU-read).
    /// Пересоздаёт только если размеры изменились.
    fn ensure_staging_texture(&mut self, width: u32, height: u32) -> Result<()> {
        if let Some(ref tex) = self.staging_texture {
            let mut desc = D3D11_TEXTURE2D_DESC::default();
            unsafe { tex.GetDesc(&mut desc) };
            if desc.Width == width && desc.Height == height {
                return Ok(());
            }
        }

        let desc = D3D11_TEXTURE2D_DESC {
            Width: width,
            Height: height,
            MipLevels: 1,
            ArraySize: 1,
            Format: DXGI_FORMAT_B8G8R8A8_UNORM,
            SampleDesc: windows::Win32::Graphics::Dxgi::Common::DXGI_SAMPLE_DESC {
                Count: 1,
                Quality: 0,
            },
            Usage: D3D11_USAGE_STAGING,
            BindFlags: D3D11_BIND_FLAG(0),
            CPUAccessFlags: D3D11_CPU_ACCESS_READ,
            MiscFlags: D3D11_RESOURCE_MISC_FLAG(0),
        };

        let texture = unsafe {
            let mut tex = None;
            self.d3d_device
                .CreateTexture2D(&desc, None, Some(&mut tex))
                .context("CreateTexture2D staging")?;
            tex.ok_or_else(|| anyhow!("Staging texture is None"))?
        };

        self.staging_texture = Some(texture);
        self.width = width;
        self.height = height;
        info!("Staging texture создана: {width}×{height}");
        Ok(())
    }

    pub fn width(&self) -> u32 {
        self.width
    }

    pub fn height(&self) -> u32 {
        self.height
    }

    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::Relaxed)
    }

    pub fn stop(&self) {
        self.running.store(false, Ordering::Relaxed);
        let _ = self.session.Close();
        let _ = self.frame_pool.Close();
        info!("WGC сессия остановлена");
    }
}

impl Drop for ScreenCapture {
    fn drop(&mut self) {
        self.stop();
        debug!("ScreenCapture dropped");
    }
}
