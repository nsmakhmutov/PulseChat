// main.rs — InPulse Media Engine (Rust Sidecar)
//
// Автономный процесс для захвата экрана, кодирования и WebRTC-трансляции.
// Управляется Python-хостом через JSON stdin/stdout.
//
// ┌─────────────┐  JSON stdin  ┌───────────────────────────────────────┐
// │ Python App  │ ───────────→ │  Rust Media Engine                    │
// │ (InPulse)   │ ←─────────── │  WGC → NVENC/AMF → WebRTC            │
// │             │  JSON stdout │                                       │
// └─────────────┘              └───────────────────────────────────────┘
//
// Запуск: media-engine.exe (без аргументов, stdin/stdout = IPC)
// Логирование: RUST_LOG=info (через env_logger / tracing)

mod capture;
mod encode;
mod ipc;
mod pipeline;
mod webrtc_out;

use anyhow::{Context, Result};
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::sync::mpsc;
use tracing::{error, info, warn};
use tracing_subscriber::EnvFilter;

use ipc::{Command, Event};
use pipeline::{Pipeline, StreamConfig};
use webrtc_out::WebRtcEvent;

const VERSION: &str = env!("CARGO_PKG_VERSION");

#[tokio::main]
async fn main() -> Result<()> {
    // ── Логирование в stderr (stdout = IPC) ──────────────────────────────────
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")),
        )
        .with_writer(std::io::stderr) // НЕ stdout!
        .with_target(false)
        .init();

    info!("InPulse Media Engine v{VERSION} запущен");

    // ── Отправляем READY ─────────────────────────────────────────────────────
    ipc::send_event(&Event::Ready {
        version: VERSION.to_string(),
    })
    .await?;

    // ── Основной IPC loop ────────────────────────────────────────────────────
    let mut pipeline: Option<Pipeline> = None;

    // WebRTC events → IPC
    let (webrtc_fwd_tx, mut webrtc_fwd_rx) = mpsc::unbounded_channel::<WebRtcEvent>();

    let stdin = tokio::io::stdin();
    let mut reader = BufReader::new(stdin);
    let mut line = String::new();

    loop {
        tokio::select! {
            // ── Входящие команды от Python ───────────────────────────────────
            result = reader.read_line(&mut line) => {
                match result {
                    Ok(0) => {
                        // EOF — Python закрыл stdin → graceful shutdown
                        info!("stdin EOF — завершаемся");
                        break;
                    }
                    Ok(_) => {
                        let trimmed = line.trim();
                        if !trimmed.is_empty() {
                            match serde_json::from_str::<Command>(trimmed) {
                                Ok(cmd) => {
                                    if let Err(e) = handle_command(
                                        cmd,
                                        &mut pipeline,
                                        &webrtc_fwd_tx,
                                    ).await {
                                        error!("Ошибка обработки команды: {e:#}");
                                        let _ = ipc::send_event(&Event::Error {
                                            message: format!("{e:#}"),
                                        }).await;
                                    }
                                }
                                Err(e) => {
                                    warn!("Невалидный JSON: {e} — строка: {trimmed}");
                                }
                            }
                        }
                        line.clear();
                    }
                    Err(e) => {
                        error!("stdin read error: {e}");
                        break;
                    }
                }
            }

            // ── WebRTC события → пересылка в Python ──────────────────────────
            Some(event) = webrtc_fwd_rx.recv() => {
                match event {
                    WebRtcEvent::Offer { sdp, sdp_type } => {
                        let _ = ipc::send_event(&Event::Offer {
                            role: "streamer".to_string(),
                            sdp,
                            sdp_type,
                        }).await;
                    }
                    WebRtcEvent::IceCandidate(candidate) => {
                        let _ = ipc::send_event(&Event::IceCandidate {
                            target: "streamer".to_string(),
                            candidate,
                        }).await;
                    }
                    WebRtcEvent::StateChanged(state) => {
                        info!("WebRTC state: {state}");
                    }
                }
            }
        }

        // Проверяем SHUTDOWN flag
        if pipeline.is_none() && line.is_empty() {
            // Нормальная работа — продолжаем
        }
    }

    // ── Graceful shutdown ────────────────────────────────────────────────────
    if let Some(mut p) = pipeline.take() {
        p.stop().await?;
    }

    info!("Media Engine завершён");
    Ok(())
}

/// Обработка одной команды от Python.
async fn handle_command(
    cmd: Command,
    pipeline: &mut Option<Pipeline>,
    webrtc_fwd_tx: &mpsc::UnboundedSender<WebRtcEvent>,
) -> Result<()> {
    match cmd {
        Command::StartStream {
            monitor,
            width,
            height,
            fps,
            bitrate,
            stream_audio,
            simulcast,
        } => {
            // Останавливаем предыдущий стрим если есть
            if let Some(mut p) = pipeline.take() {
                p.stop().await?;
            }

            let config = StreamConfig {
                monitor,
                width: width & !1, // H.264: чётные размеры
                height: height & !1,
                fps,
                bitrate,
                simulcast,
                stream_audio,
            };

            info!(
                "START_STREAM: монитор={}, {}×{} @ {} fps, {} kbps, simulcast={}",
                config.monitor,
                config.width,
                config.height,
                config.fps,
                config.bitrate / 1000,
                config.simulcast
            );

            let mut p = Pipeline::start(config)
                .await
                .context("Pipeline::start")?;

            // Перенаправляем WebRTC события в main loop
            if let Some(mut rx) = p.take_event_rx() {
                let fwd = webrtc_fwd_tx.clone();
                tokio::spawn(async move {
                    while let Some(event) = rx.recv().await {
                        if fwd.send(event).is_err() {
                            break;
                        }
                    }
                });
            }

            // Создаём WebRTC offer
            p.create_offer().await?;

            *pipeline = Some(p);
        }

        Command::StopStream => {
            if let Some(mut p) = pipeline.take() {
                p.stop().await?;
            } else {
                warn!("STOP_STREAM: стрим не запущен");
            }
        }

        Command::StreamerAnswer { sdp, sdp_type } => {
            if let Some(ref p) = pipeline {
                p.set_answer(&sdp, &sdp_type).await?;
            } else {
                warn!("STREAMER_ANSWER: стрим не запущен");
            }
        }

        Command::IceCandidate { target, candidate } => {
            if let Some(ref p) = pipeline {
                p.add_ice_candidate(&candidate).await?;
            } else {
                warn!("ICE_CANDIDATE: стрим не запущен");
            }
        }

        Command::ForceKeyframe => {
            info!("FORCE_KEYFRAME (принято, будет применено на следующем кадре)");
            // TODO: pipeline.request_keyframe()
        }

        Command::SetBitrate { bitrate, lq_bitrate } => {
            info!("SET_BITRATE: HQ={} kbps, LQ={} kbps", bitrate / 1000, lq_bitrate / 1000);
            // TODO: pipeline.set_bitrate(bitrate, lq_bitrate)
        }

        Command::ViewerOffer {
            viewer_id,
            sdp,
            sdp_type,
            quality,
        } => {
            // В текущей архитектуре viewer offer обрабатывается SFU (Python).
            // Rust Media Engine — только стример.
            warn!("VIEWER_OFFER: игнорируем (обработка на SFU)");
        }

        Command::Shutdown => {
            info!("SHUTDOWN: завершаемся...");
            if let Some(mut p) = pipeline.take() {
                p.stop().await?;
            }
            std::process::exit(0);
        }
    }

    Ok(())
}
