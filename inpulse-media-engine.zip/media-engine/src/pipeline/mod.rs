// src/pipeline/mod.rs — Конвейер: WGC Capture → HW Encode → WebRTC
//
// Архитектура потоков:
//
//   ┌──────────────┐       ┌──────────────┐       ┌──────────────┐
//   │  Capture     │  ───→ │  Encode      │  ───→ │  WebRTC      │
//   │  (отд.поток) │ Frame │  HQ + LQ     │ NALs  │  RTP Send    │
//   │  WGC + D3D11 │       │  FFmpeg NVENC│       │  webrtc-rs   │
//   └──────────────┘       └──────────────┘       └──────────────┘
//         ↑                                              ↑
//         │ START_STREAM                     OFFER/ANSWER/ICE
//         └──────── JSON stdin/stdout ───────────────────┘
//
// Поток захвата работает в отдельном OS-треде (не tokio):
//   WGC требует COM STA, D3D11 контекст не Send.
//   Кадры передаются через crossbeam channel в tokio task.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

use anyhow::{Context, Result};
use parking_lot::Mutex;
use tokio::sync::mpsc;
use tracing::{error, info, warn};

use crate::capture::{CapturedFrame, ScreenCapture};
use crate::encode::{EncodedPacket, HwEncoder, LqEncoder};
use crate::ipc::{self, Event};
use crate::webrtc_out::{StreamerPeer, WebRtcEvent};

/// Настройки стрима (из команды START_STREAM)
#[derive(Debug, Clone)]
pub struct StreamConfig {
    pub monitor: u32,
    pub width: u32,
    pub height: u32,
    pub fps: u32,
    pub bitrate: u32,
    pub simulcast: bool,
    pub stream_audio: bool,
}

impl StreamConfig {
    /// LQ разрешение = половина HQ (минимум 320×180)
    pub fn lq_resolution(&self) -> (u32, u32) {
        let w = (self.width / 2).max(320);
        let h = (self.height / 2).max(180);
        // Округляем до чётного (H.264 requirement)
        (w & !1, h & !1)
    }

    /// LQ битрейт = 1/4 от HQ
    pub fn lq_bitrate(&self) -> u32 {
        (self.bitrate / 4).max(500_000)
    }
}

/// Статистика стрима
pub struct StreamStats {
    pub frames_captured: AtomicU64,
    pub frames_encoded: AtomicU64,
    pub frames_dropped: AtomicU64,
    pub last_fps: AtomicU64,
}

impl Default for StreamStats {
    fn default() -> Self {
        Self {
            frames_captured: AtomicU64::new(0),
            frames_encoded: AtomicU64::new(0),
            frames_dropped: AtomicU64::new(0),
            last_fps: AtomicU64::new(0),
        }
    }
}

/// Менеджер конвейера захват → кодирование → WebRTC.
pub struct Pipeline {
    running: Arc<AtomicBool>,
    config: StreamConfig,
    stats: Arc<StreamStats>,
    capture_handle: Option<thread::JoinHandle<()>>,
    webrtc_peer: Option<Arc<StreamerPeer>>,
    webrtc_event_rx: Option<mpsc::UnboundedReceiver<WebRtcEvent>>,
}

impl Pipeline {
    /// Запускает конвейер: capture thread → encode → WebRTC.
    pub async fn start(config: StreamConfig) -> Result<Self> {
        let running = Arc::new(AtomicBool::new(true));
        let stats = Arc::new(StreamStats::default());

        // ── WebRTC ───────────────────────────────────────────────────────────
        let (event_tx, event_rx) = mpsc::unbounded_channel::<WebRtcEvent>();

        let webrtc_peer = Arc::new(
            StreamerPeer::new(config.simulcast, event_tx)
                .await
                .context("WebRTC PeerConnection")?,
        );

        // ── Канал кадров: capture thread → encode task ───────────────────────
        let (frame_tx, mut frame_rx) = mpsc::channel::<CapturedFrame>(4);

        // ── Capture thread (OS thread, не tokio) ─────────────────────────────
        let capture_running = running.clone();
        let capture_stats = stats.clone();
        let capture_config = config.clone();

        let capture_handle = thread::Builder::new()
            .name("wgc-capture".into())
            .spawn(move || {
                Self::capture_loop(capture_config, capture_running, capture_stats, frame_tx);
            })
            .context("Spawn capture thread")?;

        // ── Encode + Send task (tokio) ───────────────────────────────────────
        let encode_running = running.clone();
        let encode_stats = stats.clone();
        let encode_config = config.clone();
        let encode_peer = webrtc_peer.clone();

        tokio::spawn(async move {
            if let Err(e) =
                Self::encode_loop(encode_config, encode_running, encode_stats, &mut frame_rx, encode_peer)
                    .await
            {
                error!("Encode loop error: {e:#}");
                let _ = ipc::send_event(&Event::Error {
                    message: format!("Encode error: {e}"),
                })
                .await;
            }
        });

        info!(
            "Pipeline запущен: {}×{} @ {} fps, simulcast={}",
            config.width, config.height, config.fps, config.simulcast
        );

        Ok(Self {
            running,
            config,
            stats,
            capture_handle: Some(capture_handle),
            webrtc_peer: Some(webrtc_peer),
            webrtc_event_rx: Some(event_rx),
        })
    }

    // ─── Capture loop (OS thread) ────────────────────────────────────────────

    fn capture_loop(
        config: StreamConfig,
        running: Arc<AtomicBool>,
        stats: Arc<StreamStats>,
        frame_tx: mpsc::Sender<CapturedFrame>,
    ) {
        info!("Capture thread запущен");

        // Инициализируем COM для WGC (STA)
        #[cfg(windows)]
        unsafe {
            use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
            let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
        }

        let mut capture = match ScreenCapture::new(config.monitor) {
            Ok(c) => c,
            Err(e) => {
                error!("Ошибка инициализации WGC: {e:#}");
                ipc::send_event_sync(&Event::Error {
                    message: format!("WGC init error: {e}"),
                });
                return;
            }
        };

        let frame_duration = Duration::from_secs_f64(1.0 / config.fps as f64);

        while running.load(Ordering::Relaxed) {
            let t_start = Instant::now();

            match capture.grab() {
                Ok(Some(frame)) => {
                    stats.frames_captured.fetch_add(1, Ordering::Relaxed);

                    // Неблокирующая отправка: если encode не успевает — дропаем
                    match frame_tx.try_send(frame) {
                        Ok(()) => {}
                        Err(mpsc::error::TrySendError::Full(_)) => {
                            stats.frames_dropped.fetch_add(1, Ordering::Relaxed);
                        }
                        Err(mpsc::error::TrySendError::Closed(_)) => {
                            info!("Frame channel закрыт — capture thread завершается");
                            break;
                        }
                    }
                }
                Ok(None) => {
                    // Кадр не готов — WGC ещё не обновил
                }
                Err(e) => {
                    warn!("Ошибка захвата: {e:#}");
                    // Не падаем — пробуем снова (монитор мог временно отключиться)
                    thread::sleep(Duration::from_millis(100));
                    continue;
                }
            }

            // FPS limiter
            let elapsed = t_start.elapsed();
            if elapsed < frame_duration {
                // spin_sleep — точнее чем thread::sleep для коротких интервалов
                thread::sleep(frame_duration - elapsed);
            }
        }

        capture.stop();
        info!("Capture thread завершён");
    }

    // ─── Encode loop (tokio task) ────────────────────────────────────────────

    async fn encode_loop(
        config: StreamConfig,
        running: Arc<AtomicBool>,
        stats: Arc<StreamStats>,
        frame_rx: &mut mpsc::Receiver<CapturedFrame>,
        peer: Arc<StreamerPeer>,
    ) -> Result<()> {
        // Создаём HQ энкодер
        let mut hq_encoder =
            HwEncoder::new(config.width, config.height, config.fps, config.bitrate)
                .context("HQ encoder")?;

        // LQ энкодер (simulcast)
        let mut lq_encoder = if config.simulcast {
            let (lq_w, lq_h) = config.lq_resolution();
            Some(
                LqEncoder::new(
                    config.width,
                    config.height,
                    lq_w,
                    lq_h,
                    config.fps,
                    config.lq_bitrate(),
                )
                .context("LQ encoder")?,
            )
        } else {
            None
        };

        // Отправляем событие о старте
        ipc::send_event(&Event::StreamStarted {
            encoder: hq_encoder.codec_name().to_string(),
            width: config.width,
            height: config.height,
            fps: config.fps,
        })
        .await?;

        // FPS counter
        let mut fps_counter = 0u32;
        let mut fps_timer = Instant::now();

        while running.load(Ordering::Relaxed) {
            // Ждём кадр от capture thread
            let frame = match frame_rx.recv().await {
                Some(f) => f,
                None => {
                    info!("Frame channel закрыт — encode loop завершается");
                    break;
                }
            };

            // ── HQ encode ────────────────────────────────────────────────────
            match hq_encoder.encode(&frame) {
                Ok(packets) => {
                    for pkt in &packets {
                        // Отправляем в WebRTC HQ трек
                        if let Err(e) = peer.send_hq_rtp(&pkt.data).await {
                            warn!("HQ RTP send error: {e}");
                        }
                    }
                    stats.frames_encoded.fetch_add(1, Ordering::Relaxed);
                    fps_counter += 1;
                }
                Err(e) => {
                    warn!("HQ encode error: {e:#}");
                }
            }

            // ── LQ encode (simulcast) ────────────────────────────────────────
            if let Some(ref mut lq) = lq_encoder {
                match lq.encode(&frame) {
                    Ok(packets) => {
                        for pkt in &packets {
                            if let Err(e) = peer.send_lq_rtp(&pkt.data).await {
                                warn!("LQ RTP send error: {e}");
                            }
                        }
                    }
                    Err(e) => {
                        warn!("LQ encode error: {e:#}");
                    }
                }
            }

            // ── FPS stats (каждую секунду) ───────────────────────────────────
            if fps_timer.elapsed() >= Duration::from_secs(1) {
                stats.last_fps.store(fps_counter as u64, Ordering::Relaxed);

                let _ = ipc::send_event(&Event::Stats {
                    fps: fps_counter,
                    bitrate_kbps: config.bitrate / 1000,
                    encoder: hq_encoder.codec_name().to_string(),
                    dropped_frames: stats.frames_dropped.load(Ordering::Relaxed),
                })
                .await;

                fps_counter = 0;
                fps_timer = Instant::now();
            }
        }

        // Flush энкодеров
        let _ = hq_encoder.flush();
        if let Some(ref mut lq) = lq_encoder {
            let _ = lq.flush();
        }

        info!("Encode loop завершён");
        Ok(())
    }

    // ─── Public API ──────────────────────────────────────────────────────────

    /// Создаёт WebRTC offer для SFU
    pub async fn create_offer(&self) -> Result<()> {
        if let Some(ref peer) = self.webrtc_peer {
            peer.create_offer().await?;
        }
        Ok(())
    }

    /// Принимает answer от SFU
    pub async fn set_answer(&self, sdp: &str, sdp_type: &str) -> Result<()> {
        if let Some(ref peer) = self.webrtc_peer {
            peer.set_answer(sdp, sdp_type).await?;
        }
        Ok(())
    }

    /// Добавляет ICE candidate
    pub async fn add_ice_candidate(&self, candidate: &crate::ipc::IceCandidateData) -> Result<()> {
        if let Some(ref peer) = self.webrtc_peer {
            peer.add_ice_candidate(candidate).await?;
        }
        Ok(())
    }

    /// Забирает event receiver для обработки в main loop
    pub fn take_event_rx(&mut self) -> Option<mpsc::UnboundedReceiver<WebRtcEvent>> {
        self.webrtc_event_rx.take()
    }

    /// Текущие статистики
    pub fn stats(&self) -> &StreamStats {
        &self.stats
    }

    /// Останавливает конвейер
    pub async fn stop(&mut self) -> Result<()> {
        info!("Pipeline: остановка...");
        self.running.store(false, Ordering::Relaxed);

        // Закрываем WebRTC
        if let Some(ref peer) = self.webrtc_peer {
            let _ = peer.close().await;
        }
        self.webrtc_peer = None;

        // Ждём capture thread
        if let Some(handle) = self.capture_handle.take() {
            let _ = handle.join();
        }

        ipc::send_event(&Event::StreamStopped).await?;
        info!("Pipeline остановлен");
        Ok(())
    }
}

impl Drop for Pipeline {
    fn drop(&mut self) {
        self.running.store(false, Ordering::Relaxed);
    }
}
