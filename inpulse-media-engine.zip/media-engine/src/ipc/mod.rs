// src/ipc/mod.rs — JSON-протокол обмена с Python-хостом (stdin/stdout)
//
// Python → Rust (команды):
//   {"cmd": "START_STREAM", "monitor": 0, "width": 1280, "height": 720, "fps": 30, ...}
//   {"cmd": "STOP_STREAM"}
//   {"cmd": "VIEWER_OFFER", "viewer_id": "v1", "sdp": "...", "quality": "hq"}
//   {"cmd": "ICE_CANDIDATE", "target": "streamer", "candidate": {...}}
//   {"cmd": "SHUTDOWN"}
//
// Rust → Python (события):
//   {"event": "READY", "version": "0.1.0"}
//   {"event": "STREAM_STARTED"}
//   {"event": "STREAM_STOPPED"}
//   {"event": "OFFER", "role": "streamer", "sdp": "...", "type": "offer"}
//   {"event": "ANSWER", "viewer_id": "v1", "sdp": "...", "type": "answer"}
//   {"event": "ICE_CANDIDATE", "target": "...", "candidate": {...}}
//   {"event": "ERROR", "message": "..."}
//   {"event": "STATS", "fps": 30, "bitrate_kbps": 6000, "encoder": "h264_nvenc"}

use serde::{Deserialize, Serialize};

// ─── Входящие команды от Python ──────────────────────────────────────────────

#[derive(Debug, Deserialize)]
#[serde(tag = "cmd")]
pub enum Command {
    #[serde(rename = "START_STREAM")]
    StartStream {
        monitor: u32,
        width: u32,
        height: u32,
        fps: u32,
        #[serde(default = "default_bitrate")]
        bitrate: u32,
        #[serde(default)]
        stream_audio: bool,
        #[serde(default)]
        simulcast: bool,
    },

    #[serde(rename = "STOP_STREAM")]
    StopStream,

    /// SFU прислал offer зрителю → мы создаём answer
    #[serde(rename = "VIEWER_OFFER")]
    ViewerOffer {
        viewer_id: String,
        sdp: String,
        #[serde(rename = "type")]
        sdp_type: String,
        #[serde(default = "default_quality")]
        quality: String,
    },

    /// ICE candidate от SFU / зрителя
    #[serde(rename = "ICE_CANDIDATE")]
    IceCandidate {
        target: String,
        candidate: IceCandidateData,
    },

    /// Ответ SFU на наш streamer offer
    #[serde(rename = "STREAMER_ANSWER")]
    StreamerAnswer {
        sdp: String,
        #[serde(rename = "type")]
        sdp_type: String,
    },

    /// Запрос keyframe (для нового зрителя)
    #[serde(rename = "FORCE_KEYFRAME")]
    ForceKeyframe,

    /// Изменение битрейта на лету
    #[serde(rename = "SET_BITRATE")]
    SetBitrate {
        bitrate: u32,
        #[serde(default)]
        lq_bitrate: u32,
    },

    /// Корректное завершение процесса
    #[serde(rename = "SHUTDOWN")]
    Shutdown,
}

fn default_bitrate() -> u32 { 6_000_000 }
fn default_quality() -> String { "hq".into() }

// ─── ICE candidate (общий формат) ───────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IceCandidateData {
    #[serde(rename = "sdpMid")]
    pub sdp_mid: Option<String>,
    #[serde(rename = "sdpMLineIndex")]
    pub sdp_mline_index: Option<u16>,
    pub candidate: String,
}

// ─── Исходящие события в Python ──────────────────────────────────────────────

#[derive(Debug, Serialize)]
#[serde(tag = "event")]
pub enum Event {
    #[serde(rename = "READY")]
    Ready { version: String },

    #[serde(rename = "STREAM_STARTED")]
    StreamStarted {
        encoder: String,
        width: u32,
        height: u32,
        fps: u32,
    },

    #[serde(rename = "STREAM_STOPPED")]
    StreamStopped,

    /// Streamer SDP offer → Python отправит на SFU
    #[serde(rename = "OFFER")]
    Offer {
        role: String,
        sdp: String,
        #[serde(rename = "type")]
        sdp_type: String,
    },

    /// Answer для зрителя
    #[serde(rename = "ANSWER")]
    Answer {
        viewer_id: String,
        sdp: String,
        #[serde(rename = "type")]
        sdp_type: String,
    },

    #[serde(rename = "ICE_CANDIDATE")]
    IceCandidate {
        target: String,
        candidate: IceCandidateData,
    },

    #[serde(rename = "ERROR")]
    Error { message: String },

    #[serde(rename = "STATS")]
    Stats {
        fps: u32,
        bitrate_kbps: u32,
        encoder: String,
        dropped_frames: u64,
    },
}

// ─── Утилиты отправки ───────────────────────────────────────────────────────

use tokio::io::AsyncWriteExt;

/// Отправляет JSON-событие в stdout (одна строка + \n).
/// Python читает построчно: `for line in proc.stdout`.
pub async fn send_event(event: &Event) -> anyhow::Result<()> {
    let json = serde_json::to_string(event)?;
    let mut stdout = tokio::io::stdout();
    stdout.write_all(json.as_bytes()).await?;
    stdout.write_all(b"\n").await?;
    stdout.flush().await?;
    Ok(())
}

/// Блокирующая версия для вызова из синхронного контекста.
pub fn send_event_sync(event: &Event) {
    if let Ok(json) = serde_json::to_string(event) {
        // Прямая запись в stdout — не через tokio
        use std::io::Write;
        let mut out = std::io::stdout().lock();
        let _ = writeln!(out, "{json}");
        let _ = out.flush();
    }
}
