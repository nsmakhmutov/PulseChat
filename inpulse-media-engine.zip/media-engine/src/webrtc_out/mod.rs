// src/webrtc_out/mod.rs — WebRTC отправка через webrtc-rs
//
// Архитектура:
//   HwEncoder выдаёт H.264 NAL units → мы пакуем их в RTP → отправляем через
//   webrtc-rs RTCPeerConnection.
//
//   Два режима работы:
//   A) STREAMER MODE (текущий): Media Engine создаёт offer, Python пересылает на SFU.
//   B) DIRECT MODE (будущее): прямое подключение к зрителю без SFU.
//
// Интеграция с SFU:
//   Текущий SFU (server_webrtc.py) использует aiortc MediaRelay.
//   Для совместимости: Rust Media Engine заменяет ТОЛЬКО клиентскую часть
//   (стример), а SFU остаётся на Python (aiortc).
//   Сигнализация: JSON через stdin/stdout → Python → TCP → SFU.

use std::sync::Arc;

use anyhow::{Context, Result};
use parking_lot::Mutex;
use tokio::sync::mpsc;
use tracing::{debug, error, info, warn};

use webrtc::api::media_engine::MediaEngine;
use webrtc::api::APIBuilder;
use webrtc::ice_transport::ice_candidate::RTCIceCandidateInit;
use webrtc::ice_transport::ice_server::RTCIceServer;
use webrtc::peer_connection::configuration::RTCConfiguration;
use webrtc::peer_connection::peer_connection_state::RTCPeerConnectionState;
use webrtc::peer_connection::sdp::session_description::RTCSessionDescription;
use webrtc::peer_connection::RTCPeerConnection;
use webrtc::rtp_transceiver::rtp_codec::RTCRtpCodecCapability;
use webrtc::track::track_local::track_local_static_rtp::TrackLocalStaticRTP;
use webrtc::track::track_local::TrackLocal;

use crate::encode::EncodedPacket;
use crate::ipc::{self, Event, IceCandidateData};

/// События от WebRTC → IPC (Python)
pub enum WebRtcEvent {
    /// SDP offer для отправки на SFU
    Offer { sdp: String, sdp_type: String },
    /// ICE candidate
    IceCandidate(IceCandidateData),
    /// Состояние подключения изменилось
    StateChanged(String),
}

/// WebRTC менеджер для стримера.
pub struct StreamerPeer {
    pc: Arc<RTCPeerConnection>,
    hq_track: Arc<TrackLocalStaticRTP>,
    lq_track: Option<Arc<TrackLocalStaticRTP>>,
    event_tx: mpsc::UnboundedSender<WebRtcEvent>,
}

impl StreamerPeer {
    /// Создаёт RTCPeerConnection стримера с HQ (и опционально LQ) видеотреком.
    ///
    /// `ice_servers` — пустой для LAN (RadminVPN host-only ICE).
    /// `simulcast` — true = добавить LQ видеотрек (второй).
    pub async fn new(
        simulcast: bool,
        event_tx: mpsc::UnboundedSender<WebRtcEvent>,
    ) -> Result<Self> {
        // 1. Media engine: регистрируем H.264
        let mut media_engine = MediaEngine::default();
        media_engine.register_default_codecs()?;

        // 2. API
        let api = APIBuilder::new()
            .with_media_engine(media_engine)
            .build();

        // 3. Configuration — host-only ICE (LAN)
        let config = RTCConfiguration {
            ice_servers: vec![], // Пустой = host candidates only
            ..Default::default()
        };

        // 4. PeerConnection
        let pc = Arc::new(api.new_peer_connection(config).await?);
        info!("WebRTC PeerConnection создан");

        // 5. HQ видеотрек (H.264)
        let hq_track = Arc::new(TrackLocalStaticRTP::new(
            RTCRtpCodecCapability {
                mime_type: "video/H264".to_string(),
                clock_rate: 90000,
                ..Default::default()
            },
            "video-hq".to_string(),
            "inpulse-stream".to_string(),
        ));

        pc.add_track(Arc::clone(&hq_track) as Arc<dyn TrackLocal + Send + Sync>)
            .await?;
        info!("HQ видеотрек добавлен");

        // 6. LQ видеотрек (simulcast)
        let lq_track = if simulcast {
            let track = Arc::new(TrackLocalStaticRTP::new(
                RTCRtpCodecCapability {
                    mime_type: "video/H264".to_string(),
                    clock_rate: 90000,
                    ..Default::default()
                },
                "video-lq".to_string(),
                "inpulse-stream-lq".to_string(),
            ));

            pc.add_track(Arc::clone(&track) as Arc<dyn TrackLocal + Send + Sync>)
                .await?;
            info!("LQ видеотрек добавлен (simulcast)");
            Some(track)
        } else {
            None
        };

        // 7. Обработка ICE candidates
        let event_tx_ice = event_tx.clone();
        pc.on_ice_candidate(Box::new(move |candidate| {
            if let Some(c) = candidate {
                let json = c.to_json().ok();
                if let Some(j) = json {
                    let _ = event_tx_ice.send(WebRtcEvent::IceCandidate(IceCandidateData {
                        sdp_mid: j.sdp_mid.clone(),
                        sdp_mline_index: j.sdp_mline_index,
                        candidate: j.candidate.clone(),
                    }));
                }
            }
            Box::pin(async {})
        }));

        // 8. Обработка смены состояния
        let event_tx_state = event_tx.clone();
        pc.on_peer_connection_state_change(Box::new(move |state| {
            let state_str = format!("{state:?}");
            info!("WebRTC PC state → {state_str}");
            let _ = event_tx_state.send(WebRtcEvent::StateChanged(state_str.clone()));

            if state == RTCPeerConnectionState::Failed
                || state == RTCPeerConnectionState::Disconnected
            {
                warn!("WebRTC соединение потеряно: {state_str}");
            }

            Box::pin(async {})
        }));

        Ok(Self {
            pc,
            hq_track,
            lq_track,
            event_tx,
        })
    }

    /// Создаёт SDP offer и отправляет через event channel.
    pub async fn create_offer(&self) -> Result<()> {
        let offer = self.pc.create_offer(None).await?;
        self.pc.set_local_description(offer.clone()).await?;

        // Ждём ICE gathering
        // webrtc-rs собирает candidates асинхронно,
        // localDescription.sdp обновляется автоматически
        tokio::time::sleep(std::time::Duration::from_millis(500)).await;

        let local_desc = self
            .pc
            .local_description()
            .await
            .ok_or_else(|| anyhow::anyhow!("No local description"))?;

        self.event_tx
            .send(WebRtcEvent::Offer {
                sdp: local_desc.sdp.clone(),
                sdp_type: local_desc.sdp_type.to_string(),
            })
            .map_err(|e| anyhow::anyhow!("event_tx send: {e}"))?;

        info!("WebRTC offer создан и отправлен");
        Ok(())
    }

    /// Принимает SDP answer от SFU.
    pub async fn set_answer(&self, sdp: &str, sdp_type: &str) -> Result<()> {
        let answer = RTCSessionDescription::answer(sdp.to_string())?;
        self.pc.set_remote_description(answer).await?;
        info!("WebRTC answer принят");
        Ok(())
    }

    /// Добавляет ICE candidate от SFU.
    pub async fn add_ice_candidate(&self, candidate: &IceCandidateData) -> Result<()> {
        let init = RTCIceCandidateInit {
            candidate: candidate.candidate.clone(),
            sdp_mid: candidate.sdp_mid.clone(),
            sdp_mline_index: candidate.sdp_mline_index,
            ..Default::default()
        };
        self.pc.add_ice_candidate(init).await?;
        debug!("ICE candidate добавлен");
        Ok(())
    }

    /// Отправляет закодированный пакет в HQ видеотрек.
    ///
    /// `rtp_data` — уже сформированный RTP пакет (H.264 NAL → RTP packetizer).
    /// Для простоты: webrtc-rs сам пакетизирует если использовать
    /// TrackLocalStaticSample (но мы используем RTP для контроля).
    pub async fn send_hq_rtp(&self, data: &[u8]) -> Result<()> {
        self.hq_track
            .write(data)
            .await
            .context("HQ RTP write")?;
        Ok(())
    }

    /// Отправляет пакет в LQ видеотрек (simulcast).
    pub async fn send_lq_rtp(&self, data: &[u8]) -> Result<()> {
        if let Some(ref track) = self.lq_track {
            track.write(data).await.context("LQ RTP write")?;
        }
        Ok(())
    }

    /// Закрывает PeerConnection.
    pub async fn close(&self) -> Result<()> {
        self.pc.close().await?;
        info!("WebRTC PeerConnection закрыт");
        Ok(())
    }

    /// Проверяет, есть ли LQ трек
    pub fn has_lq(&self) -> bool {
        self.lq_track.is_some()
    }
}
